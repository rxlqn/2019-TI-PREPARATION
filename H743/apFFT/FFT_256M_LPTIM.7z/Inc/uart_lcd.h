 

#include "main.h"
 
 void uart_lcd_init(void);

#define BUFFERSIZE   100
extern uint8_t RxBuf[BUFFERSIZE];
