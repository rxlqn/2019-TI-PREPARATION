void Interpolation(int* src,int* dst, int iSrcLength, int iDstLength);
