void DFT_Calculate(int *Input_Squence,float *Amplitude,float *phi);
