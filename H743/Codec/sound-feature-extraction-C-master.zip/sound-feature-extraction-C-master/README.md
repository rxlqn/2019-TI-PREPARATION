# sound-feature-extraction-C
Useful feature extraction for next step classification

Code ported from https://github.com/tyiannak/pyAudioAnalysis/blob/master/audioFeatureExtraction.py

Use libsndfile http://www.mega-nerd.com/libsndfile/ for signal I/O

Usage: ./sound-feature-extraction [input sound file] [winsize (secs)] [stepsize (secs)]

Extracted features: https://github.com/tyiannak/pyAudioAnalysis/wiki/3.-Feature-Extraction
