# Uart-communication-with-Matlab-Guide
This simple graphical user interface (GUI) allows you to quickly set up a serial port for simple communication. The guide using for Double Pendulum on Cart system
